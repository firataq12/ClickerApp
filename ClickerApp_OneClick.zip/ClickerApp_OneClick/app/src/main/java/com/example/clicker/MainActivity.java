package com.example.clicker;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private long clicks;
    private TextView counter;

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        clicks = getPreferences(0).getLong("clicks", 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(30), dp(24), dp(30));
        root.setBackgroundColor(Color.rgb(16, 16, 26));

        TextView title = new TextView(this);
        title.setText("CLICKER");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);

        counter = new TextView(this);
        counter.setText(String.valueOf(clicks));
        counter.setTextColor(Color.WHITE);
        counter.setTextSize(52);
        counter.setGravity(Gravity.CENTER);

        TextView label = new TextView(this);
        label.setText("Toplam tıklama");
        label.setTextColor(Color.LTGRAY);
        label.setTextSize(16);
        label.setGravity(Gravity.CENTER);

        Button clickButton = new Button(this);
        clickButton.setText("TIKLA");
        clickButton.setTextSize(24);
        clickButton.setTextColor(Color.WHITE);

        GradientDrawable buttonBg = new GradientDrawable();
        buttonBg.setColor(Color.rgb(108, 99, 255));
        buttonBg.setCornerRadius(dp(28));
        clickButton.setBackground(buttonBg);

        LinearLayout.LayoutParams buttonParams =
                new LinearLayout.LayoutParams(-1, dp(80));
        buttonParams.setMargins(0, dp(25), 0, dp(12));
        clickButton.setLayoutParams(buttonParams);

        Button resetButton = new Button(this);
        resetButton.setText("Sıfırla");
        resetButton.setTextColor(Color.WHITE);
        resetButton.setBackgroundColor(Color.TRANSPARENT);

        clickButton.setOnClickListener(v -> {
            clicks++;
            counter.setText(String.valueOf(clicks));
            getPreferences(0).edit().putLong("clicks", clicks).apply();
        });

        resetButton.setOnClickListener(v -> {
            clicks = 0;
            counter.setText("0");
            getPreferences(0).edit().putLong("clicks", 0).apply();
        });

        root.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));
        root.addView(counter, new LinearLayout.LayoutParams(-1, dp(100)));
        root.addView(label, new LinearLayout.LayoutParams(-1, dp(40)));
        root.addView(clickButton);
        root.addView(resetButton, new LinearLayout.LayoutParams(-1, dp(55)));

        setContentView(root);
    }
}
