MOBİLDEN APK ÜRETME

1. Bu projeyi GitHub'a yükle.
2. GitHub'da repository > Actions bölümüne gir.
3. "Build Clicker APK" iş akışını seç.
4. "Run workflow" düğmesine bas.
5. İşlem bitince çıkan "Clicker-debug-apk" artifact'ini indir.
6. ZIP'i aç ve içindeki app-debug.apk dosyasını Android'e kur.

Not: Bu proje doğrudan APK değildir; GitHub Actions APK'yı otomatik olarak derler.
